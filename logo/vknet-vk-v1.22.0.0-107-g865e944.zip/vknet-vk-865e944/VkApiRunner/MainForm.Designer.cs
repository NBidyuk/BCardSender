﻿namespace VkApiRunner
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbMethodName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlParams = new System.Windows.Forms.Panel();
            this.tbParamValue10 = new System.Windows.Forms.TextBox();
            this.tbParamValue9 = new System.Windows.Forms.TextBox();
            this.tbParamValue8 = new System.Windows.Forms.TextBox();
            this.tbParamValue7 = new System.Windows.Forms.TextBox();
            this.tbParamValue6 = new System.Windows.Forms.TextBox();
            this.tbParamValue5 = new System.Windows.Forms.TextBox();
            this.tbParamValue4 = new System.Windows.Forms.TextBox();
            this.tbParamValue3 = new System.Windows.Forms.TextBox();
            this.tbParamValue2 = new System.Windows.Forms.TextBox();
            this.tbParamName10 = new System.Windows.Forms.TextBox();
            this.tbParamName9 = new System.Windows.Forms.TextBox();
            this.tbParamName8 = new System.Windows.Forms.TextBox();
            this.tbParamName7 = new System.Windows.Forms.TextBox();
            this.tbParamName6 = new System.Windows.Forms.TextBox();
            this.tbParamName5 = new System.Windows.Forms.TextBox();
            this.tbParamName4 = new System.Windows.Forms.TextBox();
            this.tbParamName3 = new System.Windows.Forms.TextBox();
            this.tbParamName2 = new System.Windows.Forms.TextBox();
            this.tbParamValue1 = new System.Windows.Forms.TextBox();
            this.tbParamName1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbJson = new System.Windows.Forms.TextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.btnGetTest = new System.Windows.Forms.Button();
            this.llVkApiUrl = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlParams.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbMethodName
            // 
            this.tbMethodName.Location = new System.Drawing.Point(12, 25);
            this.tbMethodName.Name = "tbMethodName";
            this.tbMethodName.Size = new System.Drawing.Size(214, 20);
            this.tbMethodName.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Method name:";
            // 
            // pnlParams
            // 
            this.pnlParams.Controls.Add(this.tbParamValue10);
            this.pnlParams.Controls.Add(this.tbParamValue9);
            this.pnlParams.Controls.Add(this.tbParamValue8);
            this.pnlParams.Controls.Add(this.tbParamValue7);
            this.pnlParams.Controls.Add(this.tbParamValue6);
            this.pnlParams.Controls.Add(this.tbParamValue5);
            this.pnlParams.Controls.Add(this.tbParamValue4);
            this.pnlParams.Controls.Add(this.tbParamValue3);
            this.pnlParams.Controls.Add(this.tbParamValue2);
            this.pnlParams.Controls.Add(this.tbParamName10);
            this.pnlParams.Controls.Add(this.tbParamName9);
            this.pnlParams.Controls.Add(this.tbParamName8);
            this.pnlParams.Controls.Add(this.tbParamName7);
            this.pnlParams.Controls.Add(this.tbParamName6);
            this.pnlParams.Controls.Add(this.tbParamName5);
            this.pnlParams.Controls.Add(this.tbParamName4);
            this.pnlParams.Controls.Add(this.tbParamName3);
            this.pnlParams.Controls.Add(this.tbParamName2);
            this.pnlParams.Controls.Add(this.tbParamValue1);
            this.pnlParams.Controls.Add(this.tbParamName1);
            this.pnlParams.Controls.Add(this.label3);
            this.pnlParams.Controls.Add(this.label2);
            this.pnlParams.Location = new System.Drawing.Point(12, 51);
            this.pnlParams.Name = "pnlParams";
            this.pnlParams.Size = new System.Drawing.Size(226, 286);
            this.pnlParams.TabIndex = 2;
            // 
            // tbParamValue10
            // 
            this.tbParamValue10.Location = new System.Drawing.Point(121, 260);
            this.tbParamValue10.Name = "tbParamValue10";
            this.tbParamValue10.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue10.TabIndex = 21;
            // 
            // tbParamValue9
            // 
            this.tbParamValue9.Location = new System.Drawing.Point(121, 234);
            this.tbParamValue9.Name = "tbParamValue9";
            this.tbParamValue9.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue9.TabIndex = 20;
            // 
            // tbParamValue8
            // 
            this.tbParamValue8.Location = new System.Drawing.Point(121, 208);
            this.tbParamValue8.Name = "tbParamValue8";
            this.tbParamValue8.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue8.TabIndex = 19;
            // 
            // tbParamValue7
            // 
            this.tbParamValue7.Location = new System.Drawing.Point(121, 182);
            this.tbParamValue7.Name = "tbParamValue7";
            this.tbParamValue7.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue7.TabIndex = 18;
            // 
            // tbParamValue6
            // 
            this.tbParamValue6.Location = new System.Drawing.Point(121, 156);
            this.tbParamValue6.Name = "tbParamValue6";
            this.tbParamValue6.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue6.TabIndex = 17;
            // 
            // tbParamValue5
            // 
            this.tbParamValue5.Location = new System.Drawing.Point(121, 130);
            this.tbParamValue5.Name = "tbParamValue5";
            this.tbParamValue5.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue5.TabIndex = 16;
            // 
            // tbParamValue4
            // 
            this.tbParamValue4.Location = new System.Drawing.Point(121, 104);
            this.tbParamValue4.Name = "tbParamValue4";
            this.tbParamValue4.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue4.TabIndex = 15;
            // 
            // tbParamValue3
            // 
            this.tbParamValue3.Location = new System.Drawing.Point(121, 78);
            this.tbParamValue3.Name = "tbParamValue3";
            this.tbParamValue3.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue3.TabIndex = 14;
            // 
            // tbParamValue2
            // 
            this.tbParamValue2.Location = new System.Drawing.Point(121, 52);
            this.tbParamValue2.Name = "tbParamValue2";
            this.tbParamValue2.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue2.TabIndex = 13;
            // 
            // tbParamName10
            // 
            this.tbParamName10.Location = new System.Drawing.Point(6, 260);
            this.tbParamName10.Name = "tbParamName10";
            this.tbParamName10.Size = new System.Drawing.Size(93, 20);
            this.tbParamName10.TabIndex = 12;
            // 
            // tbParamName9
            // 
            this.tbParamName9.Location = new System.Drawing.Point(6, 234);
            this.tbParamName9.Name = "tbParamName9";
            this.tbParamName9.Size = new System.Drawing.Size(93, 20);
            this.tbParamName9.TabIndex = 11;
            // 
            // tbParamName8
            // 
            this.tbParamName8.Location = new System.Drawing.Point(6, 208);
            this.tbParamName8.Name = "tbParamName8";
            this.tbParamName8.Size = new System.Drawing.Size(93, 20);
            this.tbParamName8.TabIndex = 10;
            // 
            // tbParamName7
            // 
            this.tbParamName7.Location = new System.Drawing.Point(6, 182);
            this.tbParamName7.Name = "tbParamName7";
            this.tbParamName7.Size = new System.Drawing.Size(93, 20);
            this.tbParamName7.TabIndex = 9;
            // 
            // tbParamName6
            // 
            this.tbParamName6.Location = new System.Drawing.Point(6, 156);
            this.tbParamName6.Name = "tbParamName6";
            this.tbParamName6.Size = new System.Drawing.Size(93, 20);
            this.tbParamName6.TabIndex = 8;
            // 
            // tbParamName5
            // 
            this.tbParamName5.Location = new System.Drawing.Point(6, 130);
            this.tbParamName5.Name = "tbParamName5";
            this.tbParamName5.Size = new System.Drawing.Size(93, 20);
            this.tbParamName5.TabIndex = 7;
            // 
            // tbParamName4
            // 
            this.tbParamName4.Location = new System.Drawing.Point(6, 104);
            this.tbParamName4.Name = "tbParamName4";
            this.tbParamName4.Size = new System.Drawing.Size(93, 20);
            this.tbParamName4.TabIndex = 6;
            // 
            // tbParamName3
            // 
            this.tbParamName3.Location = new System.Drawing.Point(6, 78);
            this.tbParamName3.Name = "tbParamName3";
            this.tbParamName3.Size = new System.Drawing.Size(93, 20);
            this.tbParamName3.TabIndex = 5;
            // 
            // tbParamName2
            // 
            this.tbParamName2.Location = new System.Drawing.Point(6, 52);
            this.tbParamName2.Name = "tbParamName2";
            this.tbParamName2.Size = new System.Drawing.Size(93, 20);
            this.tbParamName2.TabIndex = 4;
            // 
            // tbParamValue1
            // 
            this.tbParamValue1.Location = new System.Drawing.Point(121, 26);
            this.tbParamValue1.Name = "tbParamValue1";
            this.tbParamValue1.Size = new System.Drawing.Size(93, 20);
            this.tbParamValue1.TabIndex = 3;
            // 
            // tbParamName1
            // 
            this.tbParamName1.Location = new System.Drawing.Point(6, 26);
            this.tbParamName1.Name = "tbParamName1";
            this.tbParamName1.Size = new System.Drawing.Size(93, 20);
            this.tbParamName1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(118, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Value:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Param name:";
            // 
            // tbJson
            // 
            this.tbJson.Location = new System.Drawing.Point(244, 25);
            this.tbJson.Multiline = true;
            this.tbJson.Name = "tbJson";
            this.tbJson.Size = new System.Drawing.Size(409, 306);
            this.tbJson.TabIndex = 3;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(578, 337);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 4;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // btnGetTest
            // 
            this.btnGetTest.Enabled = false;
            this.btnGetTest.Location = new System.Drawing.Point(491, 337);
            this.btnGetTest.Name = "btnGetTest";
            this.btnGetTest.Size = new System.Drawing.Size(81, 23);
            this.btnGetTest.TabIndex = 5;
            this.btnGetTest.Text = "Get Unit-test";
            this.btnGetTest.UseVisualStyleBackColor = true;
            this.btnGetTest.Click += new System.EventHandler(this.btnGetTest_Click);
            // 
            // llVkApiUrl
            // 
            this.llVkApiUrl.AutoSize = true;
            this.llVkApiUrl.Location = new System.Drawing.Point(18, 350);
            this.llVkApiUrl.Name = "llVkApiUrl";
            this.llVkApiUrl.Size = new System.Drawing.Size(0, 13);
            this.llVkApiUrl.TabIndex = 6;
            this.llVkApiUrl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llVkApiUrl_LinkClicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(241, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Json:";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 375);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.llVkApiUrl);
            this.Controls.Add(this.btnGetTest);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.tbJson);
            this.Controls.Add(this.pnlParams);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbMethodName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VkApi Runner";
            this.pnlParams.ResumeLayout(false);
            this.pnlParams.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbMethodName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlParams;
        private System.Windows.Forms.TextBox tbParamValue10;
        private System.Windows.Forms.TextBox tbParamValue9;
        private System.Windows.Forms.TextBox tbParamValue8;
        private System.Windows.Forms.TextBox tbParamValue7;
        private System.Windows.Forms.TextBox tbParamValue6;
        private System.Windows.Forms.TextBox tbParamValue5;
        private System.Windows.Forms.TextBox tbParamValue4;
        private System.Windows.Forms.TextBox tbParamValue3;
        private System.Windows.Forms.TextBox tbParamValue2;
        private System.Windows.Forms.TextBox tbParamName10;
        private System.Windows.Forms.TextBox tbParamName9;
        private System.Windows.Forms.TextBox tbParamName8;
        private System.Windows.Forms.TextBox tbParamName7;
        private System.Windows.Forms.TextBox tbParamName6;
        private System.Windows.Forms.TextBox tbParamName5;
        private System.Windows.Forms.TextBox tbParamName4;
        private System.Windows.Forms.TextBox tbParamName3;
        private System.Windows.Forms.TextBox tbParamName2;
        private System.Windows.Forms.TextBox tbParamValue1;
        private System.Windows.Forms.TextBox tbParamName1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbJson;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Button btnGetTest;
        private System.Windows.Forms.LinkLabel llVkApiUrl;
        private System.Windows.Forms.Label label4;
    }
}

