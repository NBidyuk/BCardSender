﻿namespace VkApiRunner
{
    internal static class Placeholder
    {
        public const string MethodName = "<#METHOD_NAME#>";
        public const string Url = "<#URL#>";
        public const string Json = "<#JSON#>";
    }
}