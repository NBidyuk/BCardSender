﻿using System;

namespace VkNet.Utils
{
	/// <summary>
	/// Значение enum, используемое по умолчанию.
	/// </summary>
	public class DefaultValueAttribute : Attribute
	{

	}
}